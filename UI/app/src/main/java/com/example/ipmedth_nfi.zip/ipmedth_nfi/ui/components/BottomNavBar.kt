package com.example.ipmedth_nfi.ui.components

import androidx.compose.foundation.pager.PagerState
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import com.example.ipmedth_nfi.ui.navigation.assessmentTabs
import kotlinx.coroutines.launch

@Composable
fun BottomNavBar(pagerState: PagerState) {
    val scope = rememberCoroutineScope()

    NavigationBar() {
        assessmentTabs.forEachIndexed { index, tab ->
            NavigationBarItem(
                selected = pagerState.currentPage == index,
                onClick = {
                    scope.launch {
                        pagerState.animateScrollToPage(index)
                    }
                },
                icon = {
                    Icon(tab.icon, contentDescription = tab.title)
                },
                label = {
                    Text(tab.title, maxLines = 2)
                }
            )
        }
    }
}