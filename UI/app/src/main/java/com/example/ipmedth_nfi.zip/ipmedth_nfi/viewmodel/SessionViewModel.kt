package com.example.ipmedth_nfi.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.ipmedth_nfi.model.ExportData
import com.example.ipmedth_nfi.model.Marker
import com.example.ipmedth_nfi.model.RoomModel

class SessionViewModel : ViewModel() {
    val pageCompletion = mutableStateMapOf(
        0 to false,
        1 to false,
        2 to false,
        3 to false,
        4 to false,
        5 to false
    )
    var roomModel: RoomModel? by mutableStateOf(null)
    val markers = mutableStateListOf<Marker>()
    val appData = mutableStateMapOf<String, String>()

    fun buildExport(): ExportData {
        return ExportData(
            roomModel = roomModel,
            markers = markers.toList(),
            appData = appData.toMap()
        )
    }

    fun canCompleteFinish(): Boolean {
        return pageCompletion
            .filterKeys { it != 5 }
            .values
            .all { it }
    }
}