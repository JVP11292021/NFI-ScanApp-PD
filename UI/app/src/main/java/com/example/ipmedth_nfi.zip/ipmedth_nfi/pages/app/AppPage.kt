package com.example.ipmedth_nfi.pages.app

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import com.example.ipmedth_nfi.pages.app.tabs.*
import com.example.ipmedth_nfi.ui.components.AssessmentTopBar
import com.example.ipmedth_nfi.ui.components.BottomNavBar
import com.example.ipmedth_nfi.viewmodel.SessionViewModel

@Composable
fun AppPage(
    viewModel: SessionViewModel,
    onMenuClick: () -> Unit,
    onPageChanged: (Int) -> Unit
) {
    val pagerState = rememberPagerState(pageCount = { 6 })

    LaunchedEffect(pagerState.currentPage) {
        onPageChanged(pagerState.currentPage)
    }

    Column() {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.weight(1f)
        ) { page ->
            when (page) {
                0 -> InfoTab(viewModel)
                1 -> ObservationsTab(viewModel)
                2 -> ThemesTab(viewModel)
                3 -> AttentionTab(viewModel)
                4 -> PlanTab(viewModel)
                5 -> FinishTab(viewModel)
            }
        }
        BottomNavBar(pagerState)
    }
}