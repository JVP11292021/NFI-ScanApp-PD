package com.example.ipmedth_nfi.ui.navigation

data class AssessmentUiState(
    val currentPage: Int = 0
)