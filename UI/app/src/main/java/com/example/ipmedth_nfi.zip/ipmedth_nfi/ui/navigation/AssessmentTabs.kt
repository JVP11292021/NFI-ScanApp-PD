package com.example.ipmedth_nfi.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.ui.graphics.vector.ImageVector
import com.composables.ClipboardList
import com.composables.EyeOpen24
import com.composables.Stacks

data class AssessmentTab(
    val title: String,
    val icon: ImageVector
)

val assessmentTabs = listOf(
    AssessmentTab("Info", Icons.Outlined.Info),
    AssessmentTab("Observations", EyeOpen24),
    AssessmentTab("Themes", Stacks),
    AssessmentTab("Attention", Icons.Outlined.Warning),
    AssessmentTab("Plan", ClipboardList),
    AssessmentTab("Finish", Icons.Outlined.CheckCircle),

)
