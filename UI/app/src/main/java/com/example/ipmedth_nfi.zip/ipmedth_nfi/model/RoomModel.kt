package com.example.ipmedth_nfi.model

data class RoomModel(
    val id: String = "",
    val description: String = ""
)